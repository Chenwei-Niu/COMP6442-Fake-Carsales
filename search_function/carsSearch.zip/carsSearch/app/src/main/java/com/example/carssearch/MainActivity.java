package com.example.carssearch;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.SearchView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private SearchView searchView;
    private String currentSearchText = "";
    List<Cars> cars=new ArrayList<Cars>();
    private ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String jsonFileString = Utils.getJsonFromAssets(getApplicationContext(), "benz.json");
        //Log.i("data", jsonFileString);

        Gson gson = new Gson();
        Type listUserType = new TypeToken<List<Cars>>() { }.getType();
        cars = gson.fromJson(jsonFileString, listUserType);
        for (int i = 0; i <cars.size(); i++) {
            Log.i("cars", " Item " + i + "\n" + cars.get(i));
        }
        String jsonFileString2 = Utils.getJsonFromAssets(getApplicationContext(), "bmw.json");
        //Log.i("data", jsonFileString);

        Gson gson2 = new Gson();
        Type listUserType2 = new TypeToken<List<Cars>>() { }.getType();
        List <Cars> carsbmw = gson2.fromJson(jsonFileString2, listUserType2);
        for(Cars car : carsbmw)
            cars.add(car);
        String jsonFileString3 = Utils.getJsonFromAssets(getApplicationContext(), "ford.json");
        //Log.i("data", jsonFileString);

        Gson gson3 = new Gson();
        Type listUserType3 = new TypeToken<List<Cars>>() { }.getType();
        List <Cars> carsford = gson3.fromJson(jsonFileString3, listUserType3);
        for(Cars car : carsford)
            cars.add(car);
        String jsonFileString4 = Utils.getJsonFromAssets(getApplicationContext(), "honda.json");
        //Log.i("data", jsonFileString);

        Gson gson4 = new Gson();
        Type listUserType4 = new TypeToken<List<Cars>>() { }.getType();
        List <Cars> carshonda = gson4.fromJson(jsonFileString4, listUserType4);
        for(Cars car : carshonda)
            cars.add(car);
        String jsonFileString5 = Utils.getJsonFromAssets(getApplicationContext(), "kia.json");
        Gson gson5 = new Gson();
        Type listUserType5 = new TypeToken<List<Cars>>() { }.getType();
        List <Cars> carkia = gson5.fromJson(jsonFileString5, listUserType5);
        for(Cars car : carkia)
            cars.add(car);
        String jsonFileString6 = Utils.getJsonFromAssets(getApplicationContext(), "mazda.json");
        Gson gson6 = new Gson();
        Type listUserType6 = new TypeToken<List<Cars>>() { }.getType();
        List <Cars> carmazda = gson6.fromJson(jsonFileString6, listUserType6);
        for(Cars car : carmazda)
            cars.add(car);
        String jsonFileString7 = Utils.getJsonFromAssets(getApplicationContext(), "subaru.json");
        Gson gson7 = new Gson();
        Type listUserType7 = new TypeToken<List<Cars>>() { }.getType();
        List <Cars> carsub = gson7.fromJson(jsonFileString7, listUserType7);
        for(Cars car : carsub)
            cars.add(car);
      listView = (ListView) findViewById(R.id.carsListView);

        CarAdapter adapter = new CarAdapter(getApplicationContext(), 0, cars);
        listView.setAdapter(adapter);
        initSearchWidgets();
    }
    private void initSearchWidgets()
    {
        searchView = (SearchView) findViewById(R.id.carListSearchView);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s)
            {
                currentSearchText = s;
                ArrayList<Cars> filteredShapes = new ArrayList<Cars>();

                for(Cars car: cars)
                {
                    if(car.toString().toLowerCase().contains(s.toLowerCase()))
                    {
                        filteredShapes.add(car);

                    }
                }
                CarAdapter adapter = new CarAdapter(getApplicationContext(), 0, filteredShapes);
                listView.setAdapter(adapter);

                return false;
            }
        });
    }

}