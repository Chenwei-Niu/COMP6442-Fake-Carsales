package com.example.carssearch;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

public class CarAdapter extends ArrayAdapter<Cars>{
    public CarAdapter(Context context, int resource, List<Cars> shapeList)
    {
        super(context,resource,shapeList);
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        Cars car= getItem(position);

        if(convertView == null)
        {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.car_cell, parent, false);
        }
        TextView tv = (TextView) convertView.findViewById(R.id.carName);
        ImageView iv = (ImageView) convertView.findViewById(R.id.carImage);

        tv.setText(car.getInfomation());
//        URL url = null;
//        try {
//            url = new URL("https://carsales.pxcrush.net/carsales//car/dealer/9w0zib7tnu7r8w4v4wk2895ih.jpg?pxc_method=gravityfill&amp;pxc_bgtype=self&amp;pxc_size=720,480");
//        } catch (MalformedURLException e) {
//            e.printStackTrace();
//        }
//        Bitmap bmp = null;
//        try {
//            bmp = BitmapFactory.decodeStream(url.openConnection().getInputStream());
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        iv.setImageBitmap(bmp);
        new DownloadImageTask((ImageView) convertView.findViewById(R.id.carImage))
                .execute(car.getImage());
       // iv.setImageResource(car.getImage());


        return convertView;
    }
}
