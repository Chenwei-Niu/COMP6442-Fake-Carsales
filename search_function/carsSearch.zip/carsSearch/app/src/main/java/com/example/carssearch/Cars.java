package com.example.carssearch;

public class Cars {
    String infomation;

    @Override
    public String toString() {
        return "Cars{" +
                "name='" + infomation + '\'' +
                ", odometer=" + odometer + " , location +"+ location+ " , transmission +"+ transmission+
                ", engine=" + engine +
                '}';
    }

    String image;
    String odometer;

    public String getInfomation() {
        return infomation;
    }

    public void setInfomation(String infomation) {
        this.infomation = infomation;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getOdometer() {
        return odometer;
    }

    public void setOdometer(String odometer) {
        this.odometer = odometer;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getBodyStyle() {
        return bodyStyle;
    }

    public void setBodyStyle(String bodyStyle) {
        this.bodyStyle = bodyStyle;
    }

    public String getTransmission() {
        return transmission;
    }

    public void setTransmission(String transmission) {
        this.transmission = transmission;
    }

    public String getEngine() {
        return engine;
    }

    public void setEngine(String engine) {
        this.engine = engine;
    }

    String location;

    public Cars(String infomation, String image, String odometer, String location, String bodyStyle, String transmission, String engine) {
        this.infomation = infomation;
        this.image = image;
        this.odometer = odometer;
        this.location = location;
        this.bodyStyle = bodyStyle;
        this.transmission = transmission;
        this.engine = engine;
    }

    String bodyStyle;
    String transmission;
    String engine;

}
